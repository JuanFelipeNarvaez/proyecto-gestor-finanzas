package com.corhuila.proyectogestorfinanzas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoGestorFinanzasApplicationTests {

	@Test
	void contextLoads() {
	}

}
